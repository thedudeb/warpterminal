"use client"

import { useState, useEffect } from "react"

export default function TerminalWindow() {
  const [cursorVisible, setCursorVisible] = useState(true)
  const [input, setInput] = useState("")
  const [isAuthenticated, setIsAuthenticated] = useState(false)

  // Blinking cursor effect
  useEffect(() => {
    const interval = setInterval(() => {
      setCursorVisible((prev) => !prev)
    }, 530)

    return () => clearInterval(interval)
  }, [])

  // Handle keyboard input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isAuthenticated) return

      if (e.key === "Enter") {
        const normalizedInput = input.toLowerCase()
        if (normalizedInput === "love and reverence" || normalizedInput === "love&reverence") {
          setIsAuthenticated(true)
        } else {
          setInput("")
        }
      } else if (e.key === "Backspace") {
        setInput((prev) => prev.slice(0, -1))
      } else if (e.key.length === 1) {
        setInput((prev) => prev + e.key)
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [input, isAuthenticated])

  if (isAuthenticated) {
    return (
      <div className="w-full max-w-md mx-auto rounded-md overflow-hidden border border-gray-800 shadow-lg">
        {/* Terminal header */}
        <div className="bg-gray-900 px-4 py-2 flex items-center">
          <div className="flex space-x-2">
            <div className="w-3 h-3 rounded-full bg-red-500"></div>
            <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
            <div className="w-3 h-3 rounded-full bg-green-500"></div>
          </div>
          <div className="text-gray-400 text-xs mx-auto">Terminal</div>
        </div>

        {/* Success message */}
        <div className="bg-black p-6 font-mono text-green-500 min-h-[150px] flex flex-col items-center justify-center text-center">
          <div className="text-xl mb-4">✨ Congratulations ✨</div>
          <div className="mb-6">send this to thedude for $5 USDC</div>
          <div className="text-xs text-gray-500">Access granted</div>
        </div>
      </div>
    )
  }

  return (
    <div className="w-full max-w-md mx-auto rounded-md overflow-hidden border border-gray-800 shadow-lg">
      {/* Terminal header */}
      <div className="bg-gray-900 px-4 py-2 flex items-center">
        <div className="flex space-x-2">
          <div className="w-3 h-3 rounded-full bg-red-500"></div>
          <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
          <div className="w-3 h-3 rounded-full bg-green-500"></div>
        </div>
        <div className="text-gray-400 text-xs mx-auto">Terminal</div>
      </div>

      {/* Terminal content */}
      <div className="bg-black p-4 font-mono text-sm text-green-500 min-h-[120px] flex items-center">
        <div className="flex items-center">
          <span className="text-green-400">$</span>
          <span className="ml-2">enter password:</span>
          <span className="ml-2">
            {/* Show asterisks for each character typed */}
            {input && Array(input.length).fill("*").join("")}
            <span
              className={`inline-block w-2 h-5 ml-0.5 ${cursorVisible ? "bg-green-500" : "bg-transparent"} transition-colors duration-200`}
            ></span>
          </span>
        </div>
      </div>
    </div>
  )
}

