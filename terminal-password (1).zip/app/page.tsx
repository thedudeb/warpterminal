import TerminalWindow from "@/components/terminal-window"

export default function Home() {
  return (
    <div className="flex min-h-screen items-center justify-center p-4 bg-gray-100">
      <TerminalWindow />
    </div>
  )
}

