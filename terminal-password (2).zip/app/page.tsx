export default function Home() {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "100vh",
        fontFamily: "system-ui",
      }}
    >
      <h1>Hello World - Test Page</h1>
    </div>
  )
}

